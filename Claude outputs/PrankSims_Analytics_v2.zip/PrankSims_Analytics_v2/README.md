# PrankSims Analytics v2

Corrected and adapted version of the starter package. Start with **INSTALL.md** (steps), then **REVIEW.md** (what was wrong and why this differs).

- `site/` - files to copy into the project (new files, plus three patched components)
- `reporting/metric-dictionary.csv` - definitions that match the events
- Tested: type-check and production build pass; with a simulated country, EU visitors see the bar on the home page only and nothing loads until Yes; US visitors load GA without a bar; No sends nothing; footer link reopens the choice; prank_start, prank_engaged and prank_exit fire; choosing No deletes the _ga cookies.
