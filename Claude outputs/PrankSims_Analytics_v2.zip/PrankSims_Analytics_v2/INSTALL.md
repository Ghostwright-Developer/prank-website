# PrankSims Analytics v2 - install (about 15 minutes)

## 1. Create the GA4 property (5 min)
1. analytics.google.com > Admin > Create > Property. Name "PrankSims", your time zone, USD.
2. Create a **Web data stream** for `https://www.pranksims.com`. Leave "Enhanced measurement" ON, click its gear icon, and confirm **"Page changes based on browser history events"** is ticked. Your site changes pages without reloading, and this is what makes GA4 count those page views.
3. Copy the **Measurement ID** (looks like `G-ABC123XYZ9`).
4. Admin > Data collection > **Google signals: OFF** (we do not need ad data, and it avoids extra consent duties).
5. Admin > Data retention > Event data retention: **14 months**.
6. Admin > Data streams > your stream > Configure tag settings > **Define internal traffic**, add your own IP, then Admin > Data filters > activate "Internal Traffic" (so your testing is not counted).

## 2. Add the ID to Vercel (2 min)
Vercel > pranksims project > Settings > Environment Variables > add
`NEXT_PUBLIC_GA_ID` = your `G-...` ID (Production + Preview). **Redeploy** afterwards, because the value is baked in at build time.
For local testing, put the same line in `.env.local`. Leave it empty and GA stays completely off.

## 3. Copy files into the project (3 min)
Copy everything inside `site/` into the project root, accepting overwrites on the three components:

| New files | Overwritten (already patched, same as yours plus tracking lines) |
|---|---|
| lib/consent.ts, lib/track.ts | components/link-copier.tsx (adds an optional onCopied callback; the setup dialog still works unchanged) |
| | components/fullscreen-prank.tsx |
| components/analytics-consent.tsx | components/share-sheet.tsx |
| app/api/region/route.ts | components/exit-notice.tsx |
| app/privacy/page.tsx, app/screens/error.tsx | |

If you changed those three components since step 9, open the originals and re-add only the lines that mention `trackPrank` instead of overwriting.

## 4. Four small edits (3 min)
**app/layout.tsx** - add the import, and render it once after `<ExitNotice />` (keep your existing `<Analytics />` from Vercel):
```tsx
import { AnalyticsConsent } from "@/components/analytics-consent"
...
<ExitNotice />
<AnalyticsConsent />
```
**app/page.tsx** - add `import { CookieSettingsLink } from "@/components/analytics-consent"` and replace the footer line containing Contact with:
```tsx
<Link href="/contact" className="hover:text-cyan-400 transition-colors">Contact</Link>
{" · "}<Link href="/privacy" className="hover:text-cyan-400 transition-colors">Privacy</Link>
<CookieSettingsLink className="hover:text-cyan-400 transition-colors before:content-[' · ']" />
{" · "}&copy; {new Date().getFullYear()} {SITE_NAME}
```
**app/sitemap.ts** - add before the contact line:
```ts
{ url: absoluteUrl("/privacy"), lastModified, changeFrequency: "yearly", priority: 0.2 },
```
**.env.example** - add `NEXT_PUBLIC_GA_ID=` with a comment.

## 5. Test before announcing (5 min)
1. `npm run dev`, open the site: with no country header you are treated as "unknown", so the small bar appears bottom-left. Click Yes, open a prank, press Esc.
2. GA4 > Admin > **DebugView** (or Reports > Realtime): you should see `prank_start`, `prank_engaged` (after 10 seconds with the tab visible) and `prank_exit`. Check `prank_name` is filled in. (Event names: prank_start, prank_engaged, prank_exit, prank_next, prank_share_attempt, prank_link_copy, prank_error.)
3. Open any `/screens/...` page in a fresh private window: the bar must NOT appear there.
4. Click "Analytics settings" in the footer: the bar reopens. Click No: the `_ga` cookies are deleted and nothing more is sent, also after a reload.
5. After deploying, check your real country: from the US the bar should never appear and GA runs by default.

## 6. Register the custom definitions (5 min, do it once)
GA4 Admin > Custom definitions:

| Type | Name | Scope | Event parameter |
|---|---|---|---|
| Dimension | Prank name | Event | prank_name |
| Dimension | Prank category | Event | prank_category |
| Dimension | Share method | Event | share_method |
| Dimension | Error code | Event | error_code |
| Metric | Prank seconds | Event, unit Seconds | duration_s |

Note: `prank_exit` only fires when a viewer leaves with Esc, Q or by leaving fullscreen. Closing the tab is not seen, so use `prank_engaged` (still there after 10 seconds) as the engagement number and treat exit durations as a sample.

Optionally mark `prank_engaged` as a key event. These only fill from the day you create them, so do this first.

## 7. Commit
```
git add -A
git commit -m "Add consent-aware GA4 analytics, privacy page, prank events"
git push
```
