# What was wrong with the starter package, and what v2 does instead

## Flaws found
1. **No consent handling at all.** `PrankSimsTagManager` loaded Google on every visit, which is not allowed for EU/EEA/UK/Swiss visitors without opt-in. v2 loads GA only when permitted.
2. **Tracking fired before anything was ready.** `trackPrank` pushed to `window.dataLayer` with no check, so events from a visitor who said No still queued. v2 drops events unless analytics is allowed, and holds early events for up to 5 seconds so a prank that starts before the script loads is not lost.
3. **Never wired in.** The package only had an example. Nothing in your real prank, share or exit code called it. v2 patches those three components plus an error boundary.
4. **The example would overwrite your real `layout.tsx`** (it showed a replacement root layout, so you would lose the fonts, JSON-LD, ExitNotice and Vercel Analytics). v2 gives a two-line edit.
5. **Wrong import path** in the example (`./lib/...` instead of `@/lib/...`) and made-up prank names (`webcam_prank`, `computer_prank`). v2 uses your real slugs and fills the category automatically.
6. **GTM was extra weight for no benefit.** Tag Manager plus GA4 means two scripts, a dashboard to maintain, and a container nobody had verified. The import JSON also lacked account/container fields, so GTM may reject or mangle it. v2 uses gtag directly (one script). The old JSON is not used and not shipped.
7. **Events had undefined meaning.** `prank_complete` and `prank_variant` had no definition. v2 defines each event precisely (see the second review round below) and drops variant because the site has no variants.
8. **Referred to a "template" the README claimed was verified.** It was not, so nothing here depends on it.
9. **Single-page navigation was not considered.** Your site changes pages without reloads; GA4 enhanced measurement handles this, and v2 relies on it instead of manual page_view calls (which would double count).
10. **Reporting files described reports that do not exist** (Looker blueprint) and metric names that did not match the events. Replaced with a short metric dictionary that matches v2.
11. **Privacy risk if misused**: nothing stopped someone passing typed text into event details. v2 sends only slugs, a share method, seconds and an error name.

## Second review round (applied)
- `prank_complete` was misleading (it only fired on exit, so tab closers and anyone leaving by other means were missed). Replaced with `prank_engaged` (still on the same prank after 10 seconds) and `prank_exit` (with `duration_s`, only seen when leaving by Esc, Q or fullscreen exit). The old "completion rate" is gone.
- `prank_restart` was really "Try another" (a different random prank). Renamed `prank_next`.
- Early events are no longer thrown away after 5 seconds. They wait until analytics is definitely on (sent) or definitely off (dropped), capped at 20.
- `prank_share` over-claimed: a click on WhatsApp is not a sent message. Now `prank_share_attempt` (share routes opened) and `prank_link_copy` (link or hidden link copied) are separate.
- Choosing No after Yes now deletes the `_ga` cookies and tells Google consent is denied, besides blocking later events. The already-downloaded script stays in memory until reload, but is switched off. Country detection is a reasonable starting point, not a compliance guarantee.
- The privacy page no longer says nothing you click is sent; it describes the limited usage events honestly.
- INSTALL now has you confirm "Page changes based on browser history events" in GA4.
- Found while testing: the exit message banner sat on top of the consent bar and blocked clicks for a couple of seconds. The bar is now layered above it.

## Third review round (applied)
- Yes -> No -> Yes now sends `analytics_storage: granted` again, so Google is not left in a denied state. Tested: Yes -> No -> Yes, then a reload.
- `prank_engaged` now counts only seconds when the tab is visible (Page Visibility API). A prank left open in a background tab no longer counts. Tested with a hidden tab for 12 seconds (no event), then visible (event after 10).
- Events waiting for the category lookup re-check that analytics is still on right before sending.
- Removed the leftover `prank_variant` field.
- The hidden-link copy event now fires only after the clipboard write succeeds (new optional `onCopied` on `LinkCopier`), not when the link is read.

## What v2 is
- One tiny pill bottom-left ("Count my visit with Google Analytics? Info Yes No"), about 11px text.
- Shown only to visitors in the EU, EEA, UK, Switzerland, or whose country is unknown, only before they choose, and never on `/screens/*`, so it cannot spoil a prank.
- Everyone else is counted by default; the footer "Analytics settings" link lets anyone change their mind, anywhere.
- Country comes from a small `/api/region` route reading Vercel's header, so the rest of the site stays static and fast.
- Advertising features and Google signals are off. Vercel Web Analytics is cookie-free and unaffected.
- A `/privacy` page explains it in plain words.

## Honest caveats
- This is a sensible minimum, not legal advice. If you add ads, email capture or other trackers later, revisit it.
- GA numbers for EU/UK/CH visitors will undercount because many say No; Vercel Analytics (cookie-free) will always show the larger, truer traffic figure. Do not expect the two to match.
- Local development has no country header, so you are treated as "unknown" and see the bar.
